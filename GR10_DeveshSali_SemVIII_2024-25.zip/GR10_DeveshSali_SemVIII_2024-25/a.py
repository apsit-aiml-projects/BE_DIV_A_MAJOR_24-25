# import cv2
# import mediapipe as mp
# import numpy as np

# # Initialize Mediapipe modules
# mp_drawing = mp.solutions.drawing_utils
# mp_holistic = mp.solutions.holistic

# # Initialize webcam
# cap = cv2.VideoCapture(0)

# # Battery rectangle parameters
# battery_height = 0  # Initial height of the battery rectangle
# max_battery_height = 300  # Maximum height for the rectangle
# battery_decay_rate = 5  # How fast the battery drains
# punch_threshold = 0.1  # Movement threshold for detecting a punch
# prev_landmarks = None

# # Start Mediapipe Holistic model
# with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
#     while cap.isOpened():
#         ret, frame = cap.read()

#         if not ret:
#             break

#         # Recolor Feed
#         image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

#         # Make Detections
#         results = holistic.process(image)

#         # Recolor image back to BGR for rendering
#         image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

#         # Detect punching motion
#         if results.pose_landmarks:
#             current_landmarks = results.pose_landmarks.landmark
#             if prev_landmarks:
#                 # Calculate the movement of the right and left wrists
#                 right_wrist_movement = np.sqrt(
#                     (current_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].x -
#                      prev_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].x) ** 2 +
#                     (current_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].y -
#                      prev_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].y) ** 2
#                 )

#                 left_wrist_movement = np.sqrt(
#                     (current_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].x -
#                      prev_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].x) ** 2 +
#                     (current_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].y -
#                      prev_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].y) ** 2
#                 )

#                 # Detect punch if either wrist's movement exceeds the threshold
#                 if right_wrist_movement > punch_threshold or left_wrist_movement > punch_threshold:
#                     battery_height = min(battery_height + 30, max_battery_height)  # Increase battery height

#             prev_landmarks = current_landmarks
#         else:
#             prev_landmarks = None

#         # Battery decay over time
#         battery_height = max(battery_height - battery_decay_rate, 0)

#         # Draw battery rectangle
#         battery_top_left = (50, 400 - battery_height)
#         battery_bottom_right = (100, 400)
#         cv2.rectangle(image, (50, 100), (100, 400), (255, 255, 255), 2)  # Battery outline
#         cv2.rectangle(image, battery_top_left, battery_bottom_right, (0, 255, 0), -1)  # Battery fill

#         # Draw landmarks
#         mp_drawing.draw_landmarks(image, results.face_landmarks, mp_holistic.FACEMESH_CONTOURS,
#                                   mp_drawing.DrawingSpec(color=(80, 110, 10), thickness=3, circle_radius=1),
#                                   mp_drawing.DrawingSpec(color=(80, 256, 121), thickness=3, circle_radius=1)
#                                   )

#         mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
#                                   mp_drawing.DrawingSpec(color=(80, 22, 10), thickness=6, circle_radius=4),
#                                   mp_drawing.DrawingSpec(color=(80, 44, 121), thickness=6, circle_radius=2)
#                                   )

#         mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
#                                   mp_drawing.DrawingSpec(color=(121, 22, 76), thickness=6, circle_radius=4),
#                                   mp_drawing.DrawingSpec(color=(121, 44, 250), thickness=6, circle_radius=2)
#                                   )

#         mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS,
#                                   mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=9, circle_radius=4),
#                                   mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=6, circle_radius=2)
#                                   )

#         # Show the video feed
#         cv2.imshow('Punch Detection with Battery', image)

#         # Exit on 'q' key
#         if cv2.waitKey(10) & 0xFF == ord('q'):
#             break

# cap.release()
# cv2.destroyAllWindows()

import cv2
import mediapipe as mp
import numpy as np
import requests
import webbrowser
import time

# Initialize Mediapipe modules
mp_drawing = mp.solutions.drawing_utils
mp_holistic = mp.solutions.holistic

# Initialize webcam
cap = cv2.VideoCapture(0)

# Battery rectangle parameters
battery_height = 0
max_battery_height = 300
battery_decay_rate = 5
punch_threshold = 0.2  # Increased threshold for better detection
prev_landmarks = None

# Define the URL of the Flask server endpoint
FLASK_SERVER_URL = 'http://localhost:5000/threshold_alert'

# Start Mediapipe Holistic model
with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
    punch_detected = False  # Flag to prevent multiple browser openings
    alert_triggered_time = 0  # Time when the alert was last triggered
    cooldown_period = 10  # Cooldown period in seconds

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = holistic.process(image)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        if results.pose_landmarks:
            current_landmarks = results.pose_landmarks.landmark
            if prev_landmarks:
                right_wrist_movement = np.sqrt(
                    (current_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].x -
                     prev_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].x) ** 2 +
                    (current_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].y -
                     prev_landmarks[mp_holistic.PoseLandmark.RIGHT_WRIST].y) ** 2
                )

                left_wrist_movement = np.sqrt(
                    (current_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].x -
                     prev_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].x) ** 2 +
                    (current_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].y -
                     prev_landmarks[mp_holistic.PoseLandmark.LEFT_WRIST].y) ** 2
                )

                # Debugging output
                print(f"Right Wrist Movement: {right_wrist_movement}, Left Wrist Movement: {left_wrist_movement}")

                if (right_wrist_movement > punch_threshold or left_wrist_movement > punch_threshold):
                    current_time = time.time()
                    if not punch_detected and (current_time - alert_triggered_time) > cooldown_period:
                        webbrowser.open('http://localhost:5000/')
                        punch_detected = True  # Set the flag to True
                        alert_triggered_time = current_time  # Update the time when alert was triggered
                        battery_height = min(battery_height + 30, max_battery_height)
                        try:
                            response = requests.post(FLASK_SERVER_URL, json={"alert": "Punch threshold reached!"})
                            response.raise_for_status()  # Raise an error for bad responses
                        except requests.exceptions.RequestException as e:
                            print(f"Error sending alert: {e}")
                else:
                    punch_detected = False  # Reset when no punch is detected

            prev_landmarks = current_landmarks
        else:
            prev_landmarks = None

        battery_height = max(battery_height - battery_decay_rate, 0)
        battery_top_left = (50, 400 - battery_height)
        battery_bottom_right = (100, 400)
        cv2.rectangle(image, (50, 100), (100, 400), (255, 255, 255), 2)
        cv2.rectangle(image, battery_top_left, battery_bottom_right, (0, 255, 0), -1)

        mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS,
                                  mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=9, circle_radius=4),
                                  mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=6, circle_radius=2))

        cv2.imshow('Punch Detection with Battery', image)

        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()