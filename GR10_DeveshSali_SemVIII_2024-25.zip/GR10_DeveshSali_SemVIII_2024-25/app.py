# from flask import Flask, render_template, redirect, url_for, request, jsonify
# import csv
# import os

# app = Flask(__name__)

# # Define the path for the CSV file
# CSV_FILE = 'D:/BE/8th Sem/Jeet_final/experiences.csv'

# # Ensure the CSV file exists and has headers
# if not os.path.isfile(CSV_FILE):
#     with open(CSV_FILE, mode='w', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow(['Location', 'Risk Level', 'Experience'])

# @app.route('/')
# def alert():
#     # Serve the alert page by default
#     return render_template('alert.html')

# @app.route('/send', methods=['POST'])
# def send():
#     # Handle the "Send" button action and redirect to the index page
#     return redirect(url_for('index'))

# @app.route('/index')
# def index():
#     # Serve the index page
#     return render_template('index.html')

# @app.route('/news')
# def news():
#     # Serve the news page
#     return render_template('news.html')

# @app.route('/emergency')
# def emergency():
#     # Serve the emergency page
#     return render_template('emergency.html')

# @app.route('/submit', methods=['POST'])
# def submit_experience():
#     data = request.json
#     location = data.get('location')
#     risk_level = data.get('risk_level')
#     experience = data.get('experience')

#     # Check if the CSV file exists and write headers if it doesn't
#     file_exists = os.path.isfile(CSV_FILE)

#     # Open the CSV file in append mode
#     with open(CSV_FILE, mode='a', newline='') as file:
#         writer = csv.writer(file)
        
#         # Write headers only if the file is being created for the first time
#         if not file_exists:
#             writer.writerow(['Location', 'Risk Level', 'Experience'])  # Write headers
        
#         # Write the experience data to the CSV file
#         writer.writerow([location, risk_level, experience])  # Write data

#     return jsonify({'message': 'Experience submitted successfully!'}), 200

# @app.route('/threshold_alert', methods=['POST'])
# def threshold_alert():
#     alert_message = request.json.get("alert")
#     # Trigger any action like displaying a message, or pushing to a page, etc.
#     print(f"Alert received: {alert_message}")
#     # Optionally, you can redirect to a specific page or render a page that shows the alert
#     return jsonify({'message': 'Alert received!'}), 200

# if __name__ == '__main__':
#     app.run(debug=True)

from flask import Flask, render_template, redirect, url_for, request, jsonify
import csv
import os

app = Flask(__name__)

CSV_FILE = 'D:/BE/8th Sem/Jeet_final/experiences.csv'

if not os.path.isfile(CSV_FILE):
    with open(CSV_FILE, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Location', 'Risk Level', 'Experience'])

@app.route('/')
def alert():
    return render_template('alert.html')

@app.route('/send', methods=['POST'])
def send():
    return redirect(url_for('index'))

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/news')
def news():
    return render_template('news.html')

@app.route('/emergency')
def emergency():
    return render_template('emergency.html')

@app.route('/detection')
def detection():
    return render_template('detection.html')

@app.route('/submit', methods=['POST'])
def submit_experience():
    data = request.json
    location = data.get('location')
    risk_level = data.get('risk_level')
    experience = data.get('experience')

    file_exists = os.path.isfile(CSV_FILE)

    with open(CSV_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(['Location', 'Risk Level', 'Experience'])
        writer.writerow([location, risk_level, experience])

    return jsonify({'message': 'Experience submitted successfully!'}), 200

@app.route('/threshold_alert', methods=['POST'])
def threshold_alert():
    alert_message = request.json.get("alert")
    print(f"Alert received: {alert_message}")
    return jsonify({'message': 'Alert received!'}), 200

if __name__ == '__main__':
    app.run(debug=True)