import cv2
import mediapipe as mp
import time

# Initialize MediaPipe Hand and Pose Detectors
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
pose = mp_pose.Pose(min_detection_confidence=0.7, min_tracking_confidence=0.7)

# Initialize OpenCV for Video Capture
cap = cv2.VideoCapture(0)

# Previous positions for motion detection
prev_wrist_z = None
prev_torso_y = None

# Timer for violence detection
violence_timer = 0
VIOLENCE_DISPLAY_TIME = 4  # Time to display message (in seconds)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Flip and convert the frame for MediaPipe
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process hands and pose
    hand_results = hands.process(rgb_frame)
    pose_results = pose.process(rgb_frame)

    # Initialize violence detection flag
    violence_detected = False

    # Detect hand motion (punch)
    if hand_results.multi_hand_landmarks:
        for hand_landmarks in hand_results.multi_hand_landmarks:
            # Get wrist z-coordinate
            wrist_z = hand_landmarks.landmark[mp_hands.HandLandmark.WRIST].z

            # Detect punch motion (forward motion of the hand)
            if prev_wrist_z is not None:
                hand_motion = wrist_z - prev_wrist_z
                if hand_motion < -0.1:  # Hand moving quickly towards the camera
                    violence_detected = True

            # Update wrist z-coordinate
            prev_wrist_z = wrist_z

    # Detect body motion
    if pose_results.pose_landmarks:
        # Get torso y-coordinate (use landmark 11 or 12 for shoulders)
        torso_y = pose_results.pose_landmarks.landmark[mp_pose.PoseLandmark.LEFT_SHOULDER].y

        # Detect significant body movement
        if prev_torso_y is not None:
            body_motion = abs(torso_y - prev_torso_y)
            if body_motion > 0.05:  # Threshold for torso movement
                violence_detected = True

        # Update torso y-coordinate
        prev_torso_y = torso_y

    # Update violence timer if violence is detected
    if violence_detected:
        violence_timer = time.time()

    # Check if violence alert should be displayed
    current_time = time.time()
    if current_time - violence_timer <= VIOLENCE_DISPLAY_TIME:
        # Calculate text size and position
        text = "VIOLENCE DETECTED!"
        font_scale = 1.5
        font_thickness = 4
        font = cv2.FONT_HERSHEY_SIMPLEX

        text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]
        text_x = 30
        text_y = 80
        box_padding = 10

        # Draw red rectangle to fully cover the text
        box_start = (text_x - box_padding, text_y - text_size[1] - box_padding)
        box_end = (text_x + text_size[0] + box_padding, text_y + box_padding)
        cv2.rectangle(frame, box_start, box_end, (0, 0, 255), -1)

        # Draw the text over the red rectangle
        cv2.putText(frame, text, (text_x, text_y), font, font_scale, (255, 255, 255), font_thickness)

    # Draw landmarks for hands and pose
    if hand_results.multi_hand_landmarks:
        for hand_landmarks in hand_results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

    if pose_results.pose_landmarks:
        mp_drawing.draw_landmarks(frame, pose_results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # Display the frame
    cv2.imshow("Violence Detection", frame)

    # Exit on 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()