# from flask import Blueprint, request, jsonify
# import csv
# import os

# # Create a Blueprint for the form handling
# form_handler = Blueprint('form_handler', __name__)

# # Define the path for the CSV file
# CSV_FILE = 'experiences.csv'

# # Ensure the CSV file exists and has headers
# if not os.path.isfile(CSV_FILE):
#     with open(CSV_FILE, mode='w', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow(['Location', 'Risk Level', 'Experience'])

# @form_handler.route('/submit', methods=['POST'])
# def submit_experience():
#     data = request.json
#     location = data.get('location')
#     risk_level = data.get('risk_level')
#     experience = data.get('experience')

#     # Write to CSV
#     with open(CSV_FILE, mode='a', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow([location, risk_level, experience])

#     return jsonify({'message': 'Experience submitted successfully!'}), 200

# # ################### Section ######################
# form_handler = Blueprint('form_handler', __name__)

# CSV_FILE = 'experiences.csv'

# if not os.path.isfile(CSV_FILE):
#     with open(CSV_FILE, mode='w', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow(['Location', 'Risk Level', 'Experience'])

# @form_handler.route('/submit', methods=['POST'])
# def submit_experience():
#     data = request.json
#     location = data.get('location')
#     risk_level = data.get('risk_level')
#     experience = data.get('experience')

#     # Write to CSV
#     with open(CSV_FILE, mode='a', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow([location, risk_level, experience])

#     return jsonify({'message': 'Experience submitted successfully!'}), 200

# # ################### End Section ######################