import speech_recognition as sr

def listen_for_help():
    # Initialize recognizer
    recognizer = sr.Recognizer()

    # Use the default microphone as the audio source
    with sr.Microphone() as source:
        print("Listening for the word 'help'...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

        try:
            # Recognize speech using Google Web Speech API
            text = recognizer.recognize_google(audio)
            print("You said:", text)

            # Check if "help" is in the speech
            if "help" in text.lower():
                print("The word 'help' was detected.")
                return True
            else:
                print("No 'help' detected.")
                return False

        except sr.UnknownValueError:
            print("Sorry, I couldn't understand the audio.")
            return False
        except sr.RequestError as e:
            print(f"Error with the request: {e}")
            return False