# # # # import numpy as np
# # # # import cv2
# # # # import matplotlib.pyplot as plt
# # # # import imutils
# # # # import datetime

# # # # gun_cascade = cv2.CascadeClassifier('cascade.xml')
# # # # camera = cv2.VideoCapture(0)
# # # # firstFrame = None
# # # # gun_exist = False
# # # # while True:
# # # # 	ret, frame = camera.read()
# # # # 	if frame is None:
# # # # 		break
# # # # 	frame = imutils.resize(frame, width=500)
# # # # 	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
# # # # 	gun = gun_cascade.detectMultiScale(gray, 1.3, 20, minSize=(100, 100))
# # # # 	if len(gun) > 0:
# # # # 		gun_exist = True
# # # # 	for (x, y, w, h) in gun:
# # # # 		frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
# # # # 		roi_gray = gray[y:y + h, x:x + w]
# # # # 		roi_color = frame[y:y + h, x:x + w]
# # # # 	if firstFrame is None:
# # # # 		firstFrame = gray
# # # # 		continue
# # # # 	cv2.putText(frame, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S %p"),
# # # # 				(10, frame.shape[0] - 10),
# # # # 				cv2.FONT_HERSHEY_SIMPLEX,
# # # # 				0.35, (0, 0, 255), 1)
# # # # 	if gun_exist:
# # # # 		print("Guns detected")
# # # # 		plt.imshow(frame)
# # # # 		break
# # # # 	else:
# # # # 		cv2.imshow("Security Feed", frame)
# # # # 	key = cv2.waitKey(1) & 0xFF
# # # # 	if key == ord('q'):
# # # # 		break

# # # # camera.release()
# # # # cv2.destroyAllWindows()

# # # # import numpy as np
# # # # import cv2
# # # # import imutils
# # # # import datetime
# # # # import matplotlib.pyplot as plt

# # # # # Load the cascade
# # # # gun_cascade = cv2.CascadeClassifier('cascade.xml')
# # # # if gun_cascade.empty():
# # # #     print("Error loading cascade classifier.")
# # # #     exit()

# # # # camera = cv2.VideoCapture(0)
# # # # firstFrame = None
# # # # gun_exist = False

# # # # while True:
# # # #     ret, frame = camera.read()
# # # #     if not ret:
# # # #         print("Failed to grab frame.")
# # # #         break
    
# # # #     frame = imutils.resize(frame, width=500)
# # # #     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
# # # #     # Detect guns
# # # #     gun = gun_cascade.detectMultiScale(gray, 1.3, 20, minSize=(100, 100))
# # # #     gun_exist = False  # Reset gun_exist for each frame
    
# # # #     if len(gun) > 0:
# # # #         gun_exist = True

# # # #     for (x, y, w, h) in gun:
# # # #         frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
# # # #         roi_gray = gray[y:y + h, x:x + w]
# # # #         roi_color = frame[y:y + h, x:x + w]

# # # #     if firstFrame is None:
# # # #         firstFrame = gray

# # # #     # Add timestamp
# # # #     cv2.putText(frame, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S %p"),
# # # #                 (10, frame.shape[0] - 10),
# # # #                 cv2.FONT_HERSHEY_SIMPLEX,
# # # #                 0.35, (0, 0, 255), 1)

# # # #     # Handle gun detection
# # # #     if gun_exist:
# # # #         print("Guns detected")
# # # #         frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert BGR to RGB for plt
# # # #         plt.imshow(frame_rgb)
# # # #         plt.show()  # Display the image
# # # #         break
# # # #     else:
# # # #         cv2.imshow("Security Feed", frame)

# # # #     key = cv2.waitKey(1) & 0xFF
# # # #     if key == ord('q'):
# # # #         break

# # # # # Release camera and close windows
# # # # camera.release()
# # # # cv2.destroyAllWindows()

# # # import numpy as np
# # # import cv2
# # # import imutils
# # # import datetime
# # # import matplotlib.pyplot as plt
# # # import tkinter as tk
# # # from tkinter import filedialog
# # # from tkinter import messagebox

# # # # Load the cascade
# # # gun_cascade = cv2.CascadeClassifier('cascade.xml')
# # # if gun_cascade.empty():
# # #     print("Error loading cascade classifier.")
# # #     exit()

# # # # Function to handle live feed processing
# # # def start_live_feed():
# # #     firstFrame = None
# # #     gun_exist = False
# # #     camera = cv2.VideoCapture(0)
    
# # #     while True:
# # #         ret, frame = camera.read()
# # #         if not ret:
# # #             print("Failed to grab frame.")
# # #             break
        
# # #         frame = imutils.resize(frame, width=500)
# # #         gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
# # #         # Detect guns
# # #         gun = gun_cascade.detectMultiScale(gray, 1.3, 20, minSize=(100, 100))
# # #         gun_exist = False  # Reset gun_exist for each frame
        
# # #         if len(gun) > 0:
# # #             gun_exist = True

# # #         for (x, y, w, h) in gun:
# # #             frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
# # #             roi_gray = gray[y:y + h, x:x + w]
# # #             roi_color = frame[y:y + h, x:x + w]

# # #         if firstFrame is None:
# # #             firstFrame = gray

# # #         # Add timestamp
# # #         cv2.putText(frame, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S %p"),
# # #                     (10, frame.shape[0] - 10),
# # #                     cv2.FONT_HERSHEY_SIMPLEX,
# # #                     0.35, (0, 0, 255), 1)

# # #         # Handle gun detection
# # #         if gun_exist:
# # #             print("Guns detected")
# # #             frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert BGR to RGB for plt
# # #             plt.imshow(frame_rgb)
# # #             plt.show()  # Display the image
# # #             break
# # #         else:
# # #             cv2.imshow("Security Feed", frame)

# # #         key = cv2.waitKey(1) & 0xFF
# # #         if key == ord('q'):
# # #             break

# # #     # Release camera and close windows
# # #     camera.release()
# # #     cv2.destroyAllWindows()

# # # # Function to handle image upload and processing
# # # def upload_image():
# # #     # Open file dialog to select an image
# # #     file_path = filedialog.askopenfilename(title="Select an Image", filetypes=[("Image Files", "*.jpg;*.jpeg;*.png")])
    
# # #     if file_path:
# # #         # Process the uploaded image
# # #         image = cv2.imread(file_path)
# # #         if image is None:
# # #             messagebox.showerror("Error", "Failed to load image.")
# # #             return

# # #         image = imutils.resize(image, width=500)
# # #         gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
# # #         gun_exist = False
# # #         gun = gun_cascade.detectMultiScale(gray, 1.3, 20, minSize=(100, 100))
        
# # #         if len(gun) > 0:
# # #             gun_exist = True

# # #         for (x, y, w, h) in gun:
# # #             image = cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)

# # #         # Add timestamp
# # #         cv2.putText(image, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S %p"),
# # #                     (10, image.shape[0] - 10),
# # #                     cv2.FONT_HERSHEY_SIMPLEX,
# # #                     0.35, (0, 0, 255), 1)

# # #         if gun_exist:
# # #             print("Guns detected")
# # #             image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
# # #             plt.imshow(image_rgb)
# # #             plt.show()
# # #         else:
# # #             cv2.imshow("Processed Image", image)
# # #             cv2.waitKey(0)
# # #             cv2.destroyAllWindows()

# # # # Create the main tkinter window
# # # root = tk.Tk()
# # # root.title("Gun Detection System")

# # # # Function to handle button click for live feed
# # # def live_feed_button_click():
# # #     root.withdraw()  # Hide the tkinter window
# # #     start_live_feed()
# # #     root.deiconify()  # Show the window again

# # # # Function to handle button click for image upload
# # # def upload_image_button_click():
# # #     root.withdraw()  # Hide the tkinter window
# # #     upload_image()
# # #     root.deiconify()  # Show the window again

# # # # Create buttons for "Live Feed" and "Upload Image"
# # # live_feed_button = tk.Button(root, text="Start Live Feed", width=20, height=2, command=live_feed_button_click)
# # # upload_image_button = tk.Button(root, text="Upload Image", width=20, height=2, command=upload_image_button_click)

# # # # Place the buttons in the window
# # # live_feed_button.pack(pady=10)
# # # upload_image_button.pack(pady=10)

# # # # Start the tkinter event loop
# # # root.mainloop()

import numpy as np
import cv2
import imutils
import datetime
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox

# Load the cascade
gun_cascade = cv2.CascadeClassifier('cascade.xml')
if gun_cascade.empty():
    print("Error loading cascade classifier.")
    exit()

# Function to handle live feed processing
def start_live_feed():
    firstFrame = None
    gun_exist = False
    camera = cv2.VideoCapture(0)
    
    while True:
        ret, frame = camera.read()
        if not ret:
            print("Failed to grab frame.")
            break
        
        frame = imutils.resize(frame, width=500)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Detect guns
        gun = gun_cascade.detectMultiScale(gray, 1.3, 20, minSize=(100, 100))
        gun_exist = False  # Reset gun_exist for each frame
        
        if len(gun) > 0:
            gun_exist = True

        for (x, y, w, h) in gun:
            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Add timestamp
        cv2.putText(frame, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S %p"),
                    (10, frame.shape[0] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.35, (0, 0, 255), 1)

        # Display "Gun detected" message if guns are found
        if gun_exist:
            cv2.putText(frame, "Gun detected!", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)

        # Show the video feed with detection or "Gun detected" message
        cv2.imshow("Security Feed", frame)

        # Check for the 'q' key to stop the feed
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break

    # Release camera and close windows
    camera.release()
    cv2.destroyAllWindows()

# Function to handle image upload and processing
def upload_image():
    # Open file dialog to select an image
    file_path = filedialog.askopenfilename(title="Select an Image", filetypes=[("Image Files", "*.jpg;*.jpeg;*.png")])
    
    if file_path:
        # Process the uploaded image
        image = cv2.imread(file_path)
        if image is None:
            messagebox.showerror("Error", "Failed to load image.")
            return

        image = imutils.resize(image, width=500)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        gun_exist = False
        gun = gun_cascade.detectMultiScale(gray, 1.3, 20, minSize=(100, 100))
        
        if len(gun) > 0:
            gun_exist = True

        for (x, y, w, h) in gun:
            image = cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Add timestamp
        cv2.putText(image, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S %p"),
                    (10, image.shape[0] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.35, (0, 0, 255), 1)

        if gun_exist:
            print("Guns detected")
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            plt.imshow(image_rgb)
            plt.show()
        else:
            cv2.imshow("Processed Image", image)
            cv2.waitKey(0)
            cv2.destroyAllWindows()

# Create the main tkinter window
root = tk.Tk()
root.title("Gun Detection System")

# Function to handle button click for live feed
def live_feed_button_click():
    root.withdraw()  # Hide the tkinter window
    start_live_feed()
    root.deiconify()  # Show the window again

# Function to handle button click for image upload
def upload_image_button_click():
    root.withdraw()  # Hide the tkinter window
    upload_image()
    root.deiconify()  # Show the window again

# Create buttons for "Live Feed" and "Upload Image"
live_feed_button = tk.Button(root, text="Start Live Feed", width=20, height=2, command=live_feed_button_click)
upload_image_button = tk.Button(root, text="Upload Image", width=20, height=2, command=upload_image_button_click)

# Place the buttons in the window
live_feed_button.pack(pady=10)
upload_image_button.pack(pady=10)

# Start the tkinter event loop
root.mainloop()