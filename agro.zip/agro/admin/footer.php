<style>
   /* Footer Styling */
   footer {
            background-color: #2D6A4F;
            color: white;
            padding: 20px;
            text-align: center;
        }

        footer a {
            color: #D4A373;
            margin: 0 10px;
            font-size: 1.5rem;
            transition: 0.3s;
        }

        footer a:hover {
            color: white;
        }
</style>

<footer>
        <p>&copy; 2024 Agro for Farmers. All Rights Reserved.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>
        </div>
    </footer>