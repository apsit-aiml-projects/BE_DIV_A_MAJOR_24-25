#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>
#include "DHT.h"

// WiFi Credentials
const char* ssid = "falcon venom";
const char* password = "123456789";
char server[] = " 192.168.202.89";  

WiFiClient client;    

// DHT11 Sensor Configuration
#define DHTPIN D2
#define DHTTYPE DHT11 
DHT dht(DHTPIN, DHTTYPE);

// pH Sensor Configuration
#define SensorPin A0
unsigned long int avgValue;  
float pHValue;
int buf[10], temp;

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  // Connect to WiFi
  Serial.print("Connecting to WiFi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
  Serial.print("Local IP: ");
  Serial.println(WiFi.localIP());
}

void loop() { 
  // Read Temperature & Humidity
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  // Read pH Sensor Data
  for (int i = 0; i < 10; i++) { 
    buf[i] = analogRead(SensorPin);
    delay(10);
  }

  // Sort the readings (bubble sort)
  for (int i = 0; i < 9; i++) {
    for (int j = i + 1; j < 10; j++) {
      if (buf[i] > buf[j]) {
        temp = buf[i];
        buf[i] = buf[j];
        buf[j] = temp;
      }
    }
  }

  // Average the middle 6 values for stability
  avgValue = 0;
  for (int i = 2; i < 8; i++) {
    avgValue += buf[i];
  }

  float voltage = avgValue * (3.3 / 1024.0) / 6;
  pHValue = 3.9 * voltage;  // Updated conversion formula

  // Display values in Serial Monitor
  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print("°C, Humidity: ");
  Serial.print(humidity);
  Serial.print("%, pH: ");
  Serial.println(pHValue);

  // Send Data to Server
  if (client.connect(server, 80)) {
    Serial.println("Connected to Server");
    client.print("GET /crud/insert.php?temp=");
    client.print(temperature);
    client.print("&humi=");
    client.print(humidity);
    client.print("&ph=");
    client.print(pHValue);
    client.print(" HTTP/1.1\r\n");
    client.print("Host: ");
    client.print(server);
    client.print("\r\nConnection: close\r\n\r\n");
    client.stop();
  } else {
    Serial.println("Connection to Server Failed");
  }

  delay(5000);
}
